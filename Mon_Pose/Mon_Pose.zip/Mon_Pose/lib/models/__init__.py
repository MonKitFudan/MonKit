# --------------------------------------------------------
# Copyright (c) MonKit
# Licensed under The GNU General Public License v3.0 [see LICENSE for details]
# Modified from HRNet (https://github.com/HRNet/HigherHRNet-Human-Pose-Estimation)
# --------------------------------------------------------

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import models.pose_resnet
import models.pose_hrnet
