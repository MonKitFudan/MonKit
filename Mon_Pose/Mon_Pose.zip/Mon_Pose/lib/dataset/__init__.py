# --------------------------------------------------------
# Copyright (c) MonKit
# Licensed under The GNU General Public License v3.0 [see LICENSE for details]
# Modified from HRNet (https://github.com/HRNet/HigherHRNet-Human-Pose-Estimation)
# --------------------------------------------------------

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from .mpii import MPIIDataset as mpii
from .coco import COCODataset as coco
from .monkey_joints_14 import MonkeyDataset_14 as monkey_joints_14
from .oms import OMS as oms