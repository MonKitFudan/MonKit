# --------------------------------------------------------
# Copyright (c) MonKit
# Licensed under The GNU General Public License v3.0 [see LICENSE for details]
# Modified from HRNet (https://github.com/HRNet/HigherHRNet-Human-Pose-Estimation)
# --------------------------------------------------------

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import math

import numpy as np
import torchvision
import cv2

from core.inference import get_max_preds


def save_batch_image_with_joints(batch_image, batch_joints, batch_joints_vis,
                                 file_name, nrow=8, padding=2):
    '''
    batch_image: [batch_size, channel, height, width]
    batch_joints: [batch_size, num_joints, 3],
    batch_joints_vis: [batch_size, num_joints, 1],
    }
    '''
    grid = torchvision.utils.make_grid(batch_image, nrow, padding, True)
    ndarr = grid.mul(255).clamp(0, 255).byte().permute(1, 2, 0).cpu().numpy()
    ndarr = ndarr.copy()

    nmaps = batch_image.size(0)
    xmaps = min(nrow, nmaps)
    ymaps = int(math.ceil(float(nmaps) / xmaps))
    height = int(batch_image.size(2) + padding)
    width = int(batch_image.size(3) + padding)
    k = 0
    for y in range(ymaps):
        for x in range(xmaps):
            if k >= nmaps:
                break
            joints = batch_joints[k]
            joints_vis = batch_joints_vis[k]

            for joint, joint_vis in zip(joints, joints_vis):
                joint[0] = x * width + padding + joint[0]
                joint[1] = y * height + padding + joint[1]
                if joint_vis[0]:
                    cv2.circle(ndarr, (int(joint[0]), int(joint[1])), 2, [255, 0, 0], 2)
            k = k + 1
    cv2.imwrite(file_name, ndarr)


def save_batch_heatmaps(batch_image, batch_heatmaps, file_name,
                        normalize=True):
    '''
    batch_image: [batch_size, channel, height, width]
    batch_heatmaps: ['batch_size, num_joints, height, width]
    file_name: saved file name
    '''
    if normalize:
        batch_image = batch_image.clone()
        min = float(batch_image.min())
        max = float(batch_image.max())

        batch_image.add_(-min).div_(max - min + 1e-5)

    batch_size = batch_heatmaps.size(0)
    num_joints = batch_heatmaps.size(1)
    heatmap_height = batch_heatmaps.size(2)
    heatmap_width = batch_heatmaps.size(3)

    #print('batch_size',batch_size,'num_joints',num_joints,'heatmap_height',heatmap_height,'heatmap_width',heatmap_width)
    grid_image = np.zeros((batch_size*heatmap_height,
                           (num_joints+1)*heatmap_width,
                           3),
                          dtype=np.uint8)

    preds, maxvals = get_max_preds(batch_heatmaps.detach().cpu().numpy())
    for i in range(batch_size):
        image = batch_image[i].mul(255)\
                              .clamp(0, 255)\
                              .byte()\
                              .permute(1, 2, 0)\
                              .cpu().numpy()
        heatmaps = batch_heatmaps[i].mul(255)\
                                    .clamp(0, 255)\
                                    .byte()\
                                    .cpu().numpy()

        resized_image = cv2.resize(image,
                                   (int(heatmap_width), int(heatmap_height)))

        height_begin = heatmap_height * i
        height_end = heatmap_height * (i + 1)
        for j in range(num_joints):
            cv2.circle(resized_image,
                       (int(preds[i][j][0]), int(preds[i][j][1])),
                       1, [0, 0, 255], 1)
            heatmap = heatmaps[j, :, :]
            colored_heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
            masked_image = colored_heatmap*0.7 + resized_image*0.3
            cv2.circle(masked_image,
                       (int(preds[i][j][0]), int(preds[i][j][1])),
                       1, [0, 0, 255], 1)

            width_begin = heatmap_width * (j+1)
            width_end = heatmap_width * (j+2)
            grid_image[height_begin:height_end, width_begin:width_end, :] = masked_image
            # grid_image[height_begin:height_end, width_begin:width_end, :] = \
            #     colored_heatmap*0.7 + resized_image*0.3

        grid_image[height_begin:height_end, 0:heatmap_width, :] = resized_image

    #cv2.imwrite('/home1/lcx/CODE/deep-high-resolution/output/monkey/pose_hrnet/w48_256x256_adam_lr1e-3/resized_image.jpg',resized_image)
    # cv2.imwrite(
    #     '/home1/lcx/CODE/deep-high-resolution/output/monkey/pose_hrnet/w48_256x256_adam_lr1e-3/mask.jpg',
    #     masked_image)
    cv2.imwrite(file_name, grid_image)

def save_joint_to_pic(batch_image,batch_joints,meta, file_name,nrow=8, padding=2):
    batch_joints_vis = meta['joints_vis']
    image = meta['image']
    c = meta['center']
    scale= meta['scale'].numpy()
    print('shape',batch_joints.shape,'scale',scale.shape)
    print(scale)
    batch_joints=batch_joints*scale*200/256
    ndarr=cv2.imread(image[0])
    center=(int(c[0][0]), int(c[0][1]))
    #grid = torchvision.utils.make_grid(batch_image, nrow, padding, True)
    #ndarr = grid.mul(255).clamp(0, 255).byte().permute(1, 2, 0).cpu().numpy()
    #ndarr = ndarr.copy()

    nmaps = batch_image.size(0)
    xmaps = min(nrow, nmaps)
    ymaps = int(math.ceil(int(nmaps) / xmaps))
    height = int(batch_image.size(2) + padding)
    width = int(batch_image.size(3) + padding)
    k = 0
    color1 = [(179, 0, 0), (179, 0, 0),
                   # r hip - l hip [2,3]
                   (49, 163, 84),
                   # l leg [3, 4] [4, 5]
                   (0, 109, 45), (0, 109, 45),
                   # 尾巴 [6,7]
                   (240, 2, 127),
                   # head [8,9] [8,6]
                   (217, 95, 14), (217, 95, 14),
                   # r hand [10,11] [11,12]
                   (240, 2, 127), (240, 2, 127),
                   # shoulder [12, 13]
                   (217, 95, 14),
                   # l hand [13, 14] [14, 15]
                   (254, 153, 41), (254, 153, 41), (254, 153, 41), (254, 153, 41), (254, 153, 41)]
    # 0-2
    color2 = [(179, 0, 0), (179, 0, 0), (179, 0, 0),
                   # 3-5
                   (49, 163, 84), (49, 163, 84), (49, 163, 84),
                   # 6-7
                   (240, 2, 127), (240, 2, 127),
                   # 8-9
                   (217, 95, 14), (217, 95, 14),
                   # 10-12 r hand
                   (44, 127, 184), (44, 127, 184), (44, 127, 184),
                   # 13-15
                   (254, 153, 41), (254, 153, 41), (254, 153, 41),
                   (44, 127, 184), (0, 0, 255)]


    link_pairs1 = [
            [0, 1], [1, 2], [2, 3], [3, 4],
            [4, 5], [6, 7], [8, 9], [8, 6],
            [10, 11], [11, 12], [12, 13], [13, 14],
            [14, 15]
        ]

    for y in range(ymaps):
        for x in range(xmaps):
            if k >= nmaps:
                break
            joints = batch_joints[k]
            joints_vis = batch_joints_vis[k]
            for i in range(len(link_pairs1)):
                pointx1 = int(joints[link_pairs1[i][0]][0]) + int(c[0][0])-int(scale[0][0]*100)
                pointy1 = int(joints[link_pairs1[i][0]][1]) + int(c[0][1])-int(scale[0][0]*100)
                pointx2 = int(joints[link_pairs1[i][1]][0]) + int(c[0][0])-int(scale[0][0]*100)
                pointy2 = int(joints[link_pairs1[i][1]][1]) + int(c[0][1])-int(scale[0][0]*100)

                cv2.line(ndarr,(pointx1,pointy1) , (pointx2,pointy2),color1[i],thickness=1, lineType=8)
            i = 0
            for joint, joint_vis in zip(joints, joints_vis):
                # joint[0] = x * width + padding + joint[0]+c[0][0]-int(scale[0][0]*100)
                # joint[1] = y * height + padding + joint[1]+c[0][1]-int(scale[0][0]*100)
                joint[0] = joint[0]+c[0][0] - int(scale[0][0] * 100)
                joint[1] = joint[1]+c[0][1]-int(scale[0][0]*100)
                #if joint_vis[0]:
                #print( (int(joint[0]), int(joint[1])) )
                cv2.circle(ndarr, (int(joint[0]), int(joint[1])), 2, color2[i], 2)
                i = i + 1
            k = k + 1
    # Automatic head generation
    head_c = (joints[8]+joints[9])/2
    head_left_top_x = int(head_c[0] - scale[0][0]*100/6)
    head_left_top_y = int(head_c[1] + scale[0][0]*100/6)
    head_right_bottom_x = int(head_c[0] + scale[0][0]*100/6)
    head_right_bottom_y = int(head_c[1] - scale[0][0]*100/6)
    cv2.rectangle(ndarr, (head_left_top_x, head_left_top_y),(head_right_bottom_x, head_right_bottom_y), (0, 0, 255), 2)
    cv2.putText(ndarr, 'c',(int(c[0][0]), int(c[0][1])),cv2.FONT_HERSHEY_PLAIN, 4.0, (255, 255, 255),thickness=2)
    cv2.imwrite(file_name, ndarr)
    #cv2.imshow('imshow', ndarr)
    #cv2.waitKey(20)
    head=[[head_left_top_x,head_left_top_y],[head_right_bottom_x,head_right_bottom_y]]
    print('finish')
    return joints,head,ndarr

def save_debug_images(config, input, meta, target, joints_pred, output,
                      prefix):
    if not config.DEBUG.DEBUG:
        return

    if config.DEBUG.SAVE_BATCH_IMAGES_GT:
        save_batch_image_with_joints(
            input, meta['joints'], meta['joints_vis'],
            '{}_gt.jpg'.format(prefix)
        )
    if config.DEBUG.SAVE_BATCH_IMAGES_PRED:
        save_batch_image_with_joints(
            input, joints_pred, meta['joints_vis'],
            '{}_pred.jpg'.format(prefix)
        )
    if config.DEBUG.SAVE_HEATMAPS_GT:
        save_batch_heatmaps(
            input, target, '{}_hm_gt.jpg'.format(prefix)
        )
    if config.DEBUG.SAVE_HEATMAPS_PRED:
        save_batch_heatmaps(
            input, output, '{}_hm_pred.jpg'.format(prefix)
        )
    if config.DEBUG.SAVE_JOINT_TO_PIC:
        joints,head,pic = save_joint_to_pic(
            input, joints_pred,meta, '{}_pic.jpg'.format(prefix)
        )
