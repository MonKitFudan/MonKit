# --------------------------------------------------------
# Copyright (c) MonKit
# Licensed under The GNU General Public License v3.0 [see LICENSE for details]
# Modified from HRNet (https://github.com/HRNet/HigherHRNet-Human-Pose-Estimation)
# --------------------------------------------------------

from .default import _C as cfg
from .default import update_config
from .models import MODEL_EXTRAS
